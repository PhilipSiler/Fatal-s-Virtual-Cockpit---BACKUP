You can keep the VirtualCockpit folders anywhere you like, there is no 'install' process. Just Unzip it to somewhere then right-click VirtualCockpit.exe and 'Send' it to Desktop (makes a shortcut).

Run VirtualCockpit.exe from the Desktop icon. A VC 'control panel' will open on your PC monitor and you can select which cockpit profile to use from the list on the left hand side (there is only Spitfire IIa with the basic download but there are other 'large screen' profiles, even for the Bf109 and I think Blenheim and He111 which you can add as folders under the Cockpits folder. 

Next, in the VC 'control panel', you select which monitor to display the cockpit pit on (presumably #2) and Note that you can also tick 'Scale to Monitor' but I haven't tried that. Finally click the Start button. The cockpit will appear on your Monitor #2 but to start with you will only get a red background and 'No Connection' until you are in-game and in a cockpit.

If you get the process wrong and the cockpit appears on your PC screen it will have replaced the control panel and you will not be able to select screen #2 so just close the PC VC application and start again.

The second screen will 'hold onto' the last cockpit used when you exit the plane but will change when you select a different profile and go into that cockpit.

For each instrument there is an Include function with the name of the ini file that defines what that instrument looks like and how it behaves. These files are stored in the same directory as the cockpit.ini file

If you want to resize your instrument go into the instrument file and at the top is a section with the width and height of the instrument.

Class = Radial gauge;
Caption = Altimeter;

Width = 200;
Height = 200;
You may have to play around with the font size parameter to get it looking proper if you resize the instruments too much.

Hope this works for you! 

I have just tried out the Team Fusion virtual cockpit for the Spitty and it works great!!!!

I have all the instruments of a Spitty on my second monitor and the default has the layout of the instruments matching the cockpit of the plane. You can also play with the config files to change layout, color, etc. if you wish but I'm not there yet.

I'm attaching the files and a readme here, so if anyone is interested, and has a second monitor, this could be handy. The best part is, there's a [b][size=150]compass[/size][/b] on that virtual cockpit, so you don't have to contort yourself to see the one in the game. 

Right now, I'm working on getting warning lights set up on mine so I can be alerted if water/oil temps get too high, or my airspeed exceeds limit, etc.

Hope this helps.

